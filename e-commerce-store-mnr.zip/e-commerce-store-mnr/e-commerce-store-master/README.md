# e-commerce-store

**Free hosting use for deployement, so it might be happen response take much time and some time its down, So please run this project on local for checking.**


 ## Technology Which I Used
   ***Backend***
   
 - Nodejs
 - Mongodb
 - Express

 ***Frontend***
 

 - React Js
 - Redux

<br />

 ## Step to Start Project
 
